select name, email from contacts;
