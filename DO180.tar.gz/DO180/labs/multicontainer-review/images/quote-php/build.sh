#!/bin/bash

sudo podman build -t do180/quote-php .
