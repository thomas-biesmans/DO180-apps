# DO180 Apache HTTPd container image

This image was created to serve application static HTML files

